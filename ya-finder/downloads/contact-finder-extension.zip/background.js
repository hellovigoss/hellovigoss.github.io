import { countFound, harvestContactsFromSnapshot, mergeContacts } from "./lib/extract.js";
import { acceptedContactLines, contactLineCandidates } from "./lib/lines.js";
import { IMAGES_SOURCE, SNAPSHOT_SOURCE } from "./lib/observation.js";
import { HUD_INSTALL, scanIdsFromSnapshot } from "./lib/overlay.js";
import {
  CONTACT_GOAL,
  MAX_STEPS,
  buildSystemOneRequest,
  decideFromJev,
  pageFingerprint,
} from "./lib/jev.js";
import {
  bytesToDataUrl,
  dataUrlToBytes,
  decodeQrFromImageData,
  imageBytesToImageData,
  pickQrImages,
} from "./lib/qr.js";
import { COPY, formatError, formatProgressStep, iconStatus } from "./lib/copy.js";
import { blankRun, isWebpageUrl, reviveStoredState, startErrorForTab } from "./lib/start.js";
import { parseUrlList, planBackgroundTabs } from "./lib/batch.js";
import { clickOpensBackground, drivesInPlace, tabsToClose } from "./lib/navigate.js";
import { LINK_MENU_ID, linkMenuSpec } from "./lib/menu.js";
import { recallSite, rememberSite } from "./lib/remember.js";
import { TIMEOUTS, withTimeout } from "./lib/timeout.js";
import jsQR from "./vendor/jsqr.js";

globalThis.jsQR = jsQR;

const TARGET = (tabId) => ({ tabId });

let runSeq = 0;
let state = emptyState();
let checkedSites = {};

function emptyState() {
  return blankRun();
}

function syncActionIcon(next) {
  const icon = iconStatus(next);
  chrome.action.setBadgeText({ text: icon.badgeText }).catch(() => {});
  chrome.action.setBadgeBackgroundColor({ color: icon.badgeColor }).catch(() => {});
  chrome.action.setTitle({ title: icon.title }).catch(() => {});
  if (chrome.action.setBadgeTextColor) {
    chrome.action.setBadgeTextColor({ color: "#ffffff" }).catch(() => {});
  }
}

function publish(patch) {
  state = { ...state, ...patch, updatedAt: Date.now() };
  syncActionIcon(state);
  chrome.storage.session.set({ jevfinder: state }).catch(() => {});
  chrome.runtime.sendMessage({ type: "JEVFINDER_STATE", state }).catch(() => {});
}

function emitFind(jobIndex, patch) {
  if (jobIndex == null) {
    publish(patch);
    return;
  }
  const jobs = (state.jobs || []).map((job, i) => {
    if (i !== jobIndex) return job;
    const next = { ...job };
    for (const key of ["phones", "emails", "others", "qrs", "pages", "trace", "message", "note", "noKey"]) {
      if (patch[key] !== undefined) next[key] = patch[key];
    }
    if (patch.status) next.status = patch.status;
    return next;
  });
  publish({
    phones: patch.phones ?? state.phones,
    emails: patch.emails ?? state.emails,
    others: patch.others ?? state.others,
    qrs: patch.qrs ?? state.qrs,
    pages: patch.pages ?? state.pages,
    trace: patch.trace ?? state.trace,
    message: patch.message ?? state.message,
    phase: patch.phase ?? state.phase,
    noKey: patch.noKey,
    status: "running",
    mode: "batch",
    jobs,
  });
}

function waitTabComplete(tabId) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(onUpdated);
      resolve();
    }, 15000);
    function onUpdated(id, info) {
      if (id !== tabId || info.status !== "complete") return;
      chrome.tabs.onUpdated.removeListener(onUpdated);
      clearTimeout(timer);
      resolve();
    }
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.get(tabId).then((tab) => {
      if (tab?.status === "complete") {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        clearTimeout(timer);
        resolve();
      }
    }).catch(() => {});
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function evaluate(tabId, expression, timeoutMs = TIMEOUTS.evaluate) {
  return withTimeout(
    (async () => {
      const result = await chrome.debugger.sendCommand(TARGET(tabId), "Runtime.evaluate", {
        expression,
        returnByValue: true,
        awaitPromise: true,
      });
      if (result.exceptionDetails) {
        const text = result.exceptionDetails.text || result.exceptionDetails.exception?.description || "evaluate failed";
        throw new Error(text);
      }
      return result.result?.value;
    })(),
    timeoutMs,
    "timeout",
  );
}

async function attach(tabId) {
  try {
    await withTimeout(chrome.debugger.attach(TARGET(tabId), "1.3"), TIMEOUTS.attach, "timeout");
  } catch (err) {
    const msg = String(err?.message || err);
    if (!/already attached/i.test(msg)) throw err;
  }
  await chrome.debugger.sendCommand(TARGET(tabId), "Page.enable").catch(() => {});
  await chrome.debugger.sendCommand(TARGET(tabId), "Runtime.enable").catch(() => {});
}

async function detach(tabId) {
  try {
    await chrome.debugger.detach(TARGET(tabId));
  } catch {
    /* already detached */
  }
}

function walkResourceTree(frameTree, out = []) {
  if (!frameTree?.frame) return out;
  const frameId = frameTree.frame.id;
  for (const resource of frameTree.resources || []) {
    if (resource.type === "Image") {
      out.push({ frameId, url: resource.url, mimeType: resource.mimeType || "image/png" });
    }
  }
  for (const child of frameTree.childFrames || []) walkResourceTree(child, out);
  return out;
}

async function getImageBytes(tabId, frameId, url) {
  if (String(url).startsWith("data:")) return dataUrlToBytes(url);
  try {
    const result = await chrome.debugger.sendCommand(TARGET(tabId), "Page.getResourceContent", {
      frameId,
      url,
    });
    if (!result?.content) return null;
    if (result.base64Encoded) {
      const binary = atob(result.content);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      return { mime: "image/png", bytes };
    }
    return { mime: "text/plain", bytes: new TextEncoder().encode(result.content) };
  } catch {
    return null;
  }
}

async function downloadPng(bytes, filename) {
  const url = bytesToDataUrl(bytes, "image/png");
  try {
    const downloadId = await chrome.downloads.download({
      url,
      filename,
      saveAs: false,
      conflictAction: "uniquify",
    });
    return { downloadId, filename, dataUrl: url };
  } catch {
    return { downloadId: null, filename, dataUrl: url };
  }
}

async function collectQrs(tabId, pageUrl, seenSrc = new Set()) {
  let images = [];
  try {
    images = (await evaluate(tabId, IMAGES_SOURCE, TIMEOUTS.images)) || [];
  } catch {
    return [];
  }
  const queue = pickQrImages(images).filter((image) => image.src && !seenSrc.has(image.src));
  if (!queue.length) return [];
  let resources = [];
  try {
    const tree = await withTimeout(
      chrome.debugger.sendCommand(TARGET(tabId), "Page.getResourceTree"),
      TIMEOUTS.images,
      "timeout",
    );
    resources = walkResourceTree(tree.frameTree);
  } catch {
    resources = [];
  }
  const host = (() => {
    try {
      return new URL(pageUrl).hostname.replace(/[^a-z0-9.-]/gi, "_") || "site";
    } catch {
      return "site";
    }
  })();
  const found = [];
  for (const image of queue) {
    seenSrc.add(image.src);
    try {
      const item = await withTimeout(
        (async () => {
          const resource = resources.find((r) => r.url === image.src) || resources[0];
          const packed = await getImageBytes(tabId, resource?.frameId, image.src);
          if (!packed?.bytes?.byteLength) return null;
          const imageData = await imageBytesToImageData(packed.bytes, packed.mime || "image/png");
          const decoded = decodeQrFromImageData(imageData, jsQR);
          if (!decoded) return null;
          const filename = `JevFinder/${host}-qr-${found.length + 1}.png`;
          const saved = await downloadPng(packed.bytes, filename);
          return {
            payload: decoded.payload,
            src: image.src,
            alt: image.alt || "",
            filename: saved.filename,
            downloadId: saved.downloadId,
            dataUrl: saved.dataUrl,
            bytes: packed.bytes.byteLength,
          };
        })(),
        TIMEOUTS.qrImage,
        "timeout",
      );
      if (item) found.push(item);
    } catch {
      /* skip this image */
    }
  }
  return found;
}

async function hudCall(tabId, expression) {
  try {
    return await evaluate(tabId, expression, 2500);
  } catch (err) {
    console.error("hud", String(err?.message || err));
    return null;
  }
}

async function hudInstall(tabId) {
  await hudCall(tabId, HUD_INSTALL);
}

async function hudScan(tabId, snapshot) {
  const ids = scanIdsFromSnapshot(snapshot);
  await hudCall(tabId, `window.__jevFinderHud&&window.__jevFinderHud.scan(${JSON.stringify(ids)})`);
  await sleep(80);
}

async function hudMark(tabId, harvested) {
  const payload = {
    phones: harvested.phones || [],
    emails: harvested.emails || [],
    others: harvested.others || [],
    qrs: (harvested.qrs || []).map((qr) => qr.src).filter(Boolean),
  };
  await hudCall(tabId, `window.__jevFinderHud&&window.__jevFinderHud.mark(${JSON.stringify(payload)})`);
}

async function hudFocus(tabId, node) {
  if (node == null) return;
  await hudCall(tabId, `window.__jevFinderHud&&window.__jevFinderHud.focus(${JSON.stringify(node)})`);
  await sleep(150);
}

async function hudTeardown(tabId) {
  await hudCall(tabId, `window.__jevFinderHud&&window.__jevFinderHud.teardown()`);
}

async function waitForSettle(tabId) {
  try {
    await evaluate(
      tabId,
      `new Promise((resolve) => {
        const done = () => resolve(document.readyState);
        if (document.readyState === "complete") {
          requestAnimationFrame(() => requestAnimationFrame(done));
          return;
        }
        window.addEventListener("load", () => requestAnimationFrame(done), { once: true });
        setTimeout(done, 2500);
      })`,
      TIMEOUTS.settle,
    );
  } catch {
    /* page did not settle in time */
  }
  await sleep(200);
}

async function openQuietTab(url, openerTabId) {
  const opener = await chrome.tabs.get(openerTabId).catch(() => null);
  const props = { url, active: false };
  if (opener?.id) {
    props.openerTabId = opener.id;
    if (opener.windowId != null) props.windowId = opener.windowId;
    if (Number.isInteger(opener.index)) props.index = opener.index + 1;
  }
  let created;
  try {
    created = await chrome.tabs.create(props);
  } catch (err) {
    if (!props.openerTabId) throw err;
    created = await chrome.tabs.create({ url, active: false, windowId: props.windowId });
  }
  await waitTabComplete(created.id);
  return created;
}

async function clickHint(tabId, action) {
  const hint = {
    href: action?.href || "",
    label: String(action?.label || "")
      .replace(/^Open\s+/i, "")
      .slice(0, 80),
  };
  await evaluate(
    tabId,
    `(async (hint) => {
      const nodes = [...document.querySelectorAll("a,button,input,[role='button'],[role='link'],summary")];
      let el = null;
      if (hint.href) el = nodes.find((node) => node.href === hint.href);
      if (!el && hint.label) {
        el = nodes.find((node) => (node.innerText || node.value || "").trim().includes(hint.label));
      }
      if (!el) return { ok: false };
      el.scrollIntoView({ block: "center", inline: "center" });
      el.click();
      return { ok: true };
    })(${JSON.stringify(hint)})`,
  );
}

async function executeResolved(tabId, resolved, { scrollY = 0, keepTabId = null } = {}) {
  const action = resolved.action;
  if (!action || action.kind === "stop") return { nextTabId: tabId };
  const tab = await chrome.tabs.get(tabId);
  const stay = drivesInPlace(tab.id, { active: tab.active, keepTabId });
  if (action.kind === "click") {
    await hudFocus(tabId, action.node);
    const plan = clickOpensBackground(action, tab.url || "");
    let opened = null;
    try {
      if (plan.mode === "open") {
        if (!stay) {
          opened = await openQuietTab(plan.url, tabId);
          return { nextTabId: opened.id };
        }
        await chrome.tabs.update(tabId, { url: plan.url });
        await waitTabComplete(tabId);
        return { nextTabId: tabId };
      }
      if (!stay) {
        opened = await openQuietTab(tab.url, tabId);
        await attach(opened.id);
        await waitForSettle(opened.id);
        await clickHint(opened.id, action);
        await waitForSettle(opened.id);
        return { nextTabId: opened.id };
      }
      await clickHint(tabId, action);
      await waitForSettle(tabId);
      return { nextTabId: tabId };
    } catch (err) {
      if (opened?.id) await detach(opened.id);
      throw err;
    }
  }
  if (action.kind === "scroll") {
    const delta = Number(action.delta) || 560;
    if (!stay) {
      let opened = null;
      try {
        opened = await openQuietTab(tab.url, tabId);
        await attach(opened.id);
        const y = Math.max(0, Math.round(Number(scrollY) || 0));
        await evaluate(opened.id, `window.scrollTo(0, ${y})`);
        await evaluate(opened.id, `window.scrollBy(0, ${Math.round(delta)})`);
        await sleep(200);
        return { nextTabId: opened.id };
      } catch (err) {
        if (opened?.id) await detach(opened.id);
        throw err;
      }
    }
    await evaluate(tabId, `window.scrollBy(0, ${Math.round(delta)})`);
    await sleep(200);
    return { nextTabId: tabId };
  }
  if (action.kind === "wait") {
    await sleep(400);
  }
  return { nextTabId: tabId };
}

async function readApiKey() {
  const stored = await chrome.storage.sync.get(["typesafeApiKey"]);
  return String(stored.typesafeApiKey || "").trim();
}

async function ensureApiKey() {
  const apiKey = await readApiKey();
  if (apiKey) return true;
  publish({
    ...emptyState(),
    status: "error",
    error: COPY.errorNoKey,
    message: COPY.errorNoKey,
  });
  return false;
}

async function askJev(request, apiKey) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUTS.jev);
  try {
    const response = await fetch(request.url, {
      method: request.method,
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(request.body),
      signal: ctrl.signal,
    });
    const text = await response.text();
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      json = { raw: text };
    }
    if (!response.ok) {
      throw new Error("lookup-failed");
    }
    return json;
  } catch (err) {
    if (ctrl.signal.aborted || /abort|timeout/i.test(String(err?.message || err))) {
      throw new Error("timeout");
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

function mergeQrs(existing, incoming) {
  const out = [...existing];
  for (const qr of incoming) {
    if (out.some((q) => q.payload === qr.payload && q.src === qr.src)) continue;
    out.push(qr);
  }
  return out;
}

function storeSite(url, found) {
  checkedSites = rememberSite(checkedSites, url, found);
  chrome.storage.session.set({ checkedSites }).catch(() => {});
}

function rememberedFlags(sourceUrl, contacts, qrs, { noKey = false } = {}) {
  if (!sourceUrl) return {};
  const phones = contacts?.phones || [];
  const emails = contacts?.emails || [];
  const others = contacts?.others || [];
  storeSite(sourceUrl, { phones, emails, others, qrs });
  const empty = countFound({ phones, emails, others }, qrs) === 0;
  if (!empty) return { alreadyChecked: true };
  const message = noKey ? COPY.statusNoKeyEmpty : COPY.statusAlreadyEmpty;
  return {
    alreadyEmpty: true,
    status: "done",
    message,
    note: message,
  };
}

function memoryState(saved, tab) {
  const empty = Boolean(saved?.empty);
  return {
    ...emptyState(),
    status: "done",
    alreadyEmpty: empty,
    alreadyChecked: !empty,
    message: empty ? COPY.statusAlreadyEmpty : COPY.statusDone,
    phones: saved?.phones || [],
    emails: saved?.emails || [],
    others: saved?.others || [],
    qrs: saved?.qrs || [],
    sourceUrl: tab?.url || "",
    tabId: tab?.id ?? null,
  };
}

function finishFind(emit, { foundNow, contacts, qrs, pages, history, resolved, noKey, timedOut, sourceUrl }) {
  const operation = resolved?.operation;
  const hasFind = foundNow > 0;
  let status = "done";
  let message = hasFind ? COPY.statusDone : COPY.statusDoneEmpty;
  if (timedOut) {
    message = COPY.statusTimeout;
  } else if (operation === "BLOCKED") {
    status = hasFind ? "done" : "blocked";
    message = hasFind ? COPY.statusBlocked : COPY.statusBlocked;
  } else if (noKey) {
    message = hasFind ? COPY.statusNoKeyFound : COPY.statusNoKeyEmpty;
  } else if (operation === "DONE") {
    message = hasFind ? COPY.statusDone : COPY.statusDoneEmpty;
  }
  const memory = rememberedFlags(sourceUrl, contacts, qrs, { noKey });
  if (memory.alreadyEmpty) {
    status = memory.status;
    message = memory.message;
  }
  emit({
    status,
    noKey: Boolean(noKey),
    timedOut: Boolean(timedOut),
    alreadyEmpty: Boolean(memory.alreadyEmpty),
    alreadyChecked: Boolean(memory.alreadyChecked),
    note: memory.note || "",
    message,
    phones: contacts.phones,
    emails: contacts.emails,
    others: contacts.others,
    qrs,
    pages,
    trace: history,
    sourceUrl: sourceUrl || "",
  });
  return state;
}

async function runFind(tabId, { jobIndex, seq: givenSeq, sourceUrl = "", keepTabId = null } = {}) {
  const keep = jobIndex != null;
  if (givenSeq != null && givenSeq !== runSeq) return state;
  const seq = givenSeq ?? (keep ? runSeq : ++runSeq);
  const askedUrl = sourceUrl || "";
  const emit = (patch) => emitFind(jobIndex, patch);
  if (!keep) {
    publish({
      ...emptyState(),
      status: "running",
      phase: "observe",
      message: COPY.statusStarting,
      tabId,
      sourceUrl: askedUrl,
      startedAt: Date.now(),
    });
  } else {
    emit({ status: "running", phase: "observe", message: COPY.statusStarting });
  }

  const history = [];
  let contacts = { emails: [], phones: [], others: [] };
  let qrs = [];
  const pages = [];
  const seenQrSrc = new Set();
  let previousFingerprint = null;
  let previousFound = 0;
  const deadline = Date.now() + TIMEOUTS.run;

  const tally = () => countFound(contacts, qrs);
  const snapshotHarvest = (extra = {}) => ({
    phones: contacts.phones,
    emails: contacts.emails,
    others: contacts.others,
    qrs,
    pages,
    trace: history,
    ...extra,
  });

  let driveTab = tabId;
  const sessionTabs = new Set([tabId]);

  try {
    const apiKey = await readApiKey();
    if (!apiKey) {
      emit({
        status: "error",
        error: COPY.errorNoKey,
        message: COPY.errorNoKey,
      });
      return state;
    }
    await attach(driveTab);
    await hudInstall(driveTab);
    for (let step = 0; step < MAX_STEPS; step++) {
      if (seq !== runSeq) return state;
      if (Date.now() > deadline) {
        return finishFind(emit, {
          foundNow: tally(),
          contacts,
          qrs,
          pages,
          history,
          timedOut: true,
          sourceUrl: askedUrl,
        });
      }
      emit({ status: "running", phase: "observe", message: COPY.statusLookingPage });

      const snapshot = await evaluate(driveTab, SNAPSHOT_SOURCE);
      if (!snapshot) throw new Error("lookup-failed");
      await hudInstall(driveTab);
      await hudScan(driveTab, snapshot);
      const fingerprint = pageFingerprint(snapshot);
      if (history.length) {
        history[history.length - 1].page_changed = fingerprint !== previousFingerprint;
      }
      previousFingerprint = fingerprint;
      pages.push({ url: snapshot.url, title: snapshot.title });
      contacts = mergeContacts(contacts, harvestContactsFromSnapshot(snapshot));

      emit({
        ...snapshotHarvest(),
        phase: "qr",
        message: COPY.statusLookingQr,
      });
      const pageQrs = await collectQrs(driveTab, snapshot.url, seenQrSrc);
      qrs = mergeQrs(qrs, pageQrs);
      await hudMark(driveTab, {
        phones: contacts.phones,
        emails: contacts.emails,
        others: contacts.others,
        qrs,
      });

      let foundNow = tally();
      const harvestGrew = foundNow > previousFound;
      previousFound = foundNow;
      emit(snapshotHarvest());

      const unchanged = history.slice(-3);
      if (
        unchanged.length === 3 &&
        unchanged.every((h) => h.page_changed === false && h.kind !== "wait")
      ) {
        const stuckMemory = rememberedFlags(askedUrl, contacts, qrs);
        emit({
          ...snapshotHarvest(),
          status: stuckMemory.alreadyEmpty ? "done" : foundNow ? "done" : "blocked",
          message: stuckMemory.message || COPY.statusStuck,
          note: stuckMemory.note || "",
          alreadyEmpty: Boolean(stuckMemory.alreadyEmpty),
          alreadyChecked: Boolean(stuckMemory.alreadyChecked),
          sourceUrl: askedUrl,
        });
        return state;
      }

      const request = buildSystemOneRequest({
        snapshot,
        history,
        harvested: {
          phones: contacts.phones,
          emails: contacts.emails,
          others: contacts.others,
          qr_count: qrs.length,
        },
        goal: CONTACT_GOAL,
      });
      let resolved;
      let answers = {};
      let model;
      emit({ phase: "decide", message: COPY.statusThinking });
      const jev = await askJev(request, apiKey);
      answers = jev.answers || {};
      model = jev.model;
      const lines = contactLineCandidates(snapshot.text);
      contacts = mergeContacts(contacts, {
        others: acceptedContactLines(lines, answers, {
          known: [...contacts.phones, ...contacts.emails],
        }),
      });
      foundNow = tally();
      previousFound = foundNow;
      await hudMark(driveTab, {
        phones: contacts.phones,
        emails: contacts.emails,
        others: contacts.others,
        qrs,
      });
      resolved = decideFromJev(answers, request, {
        harvested: { phones: contacts.phones, emails: contacts.emails, others: contacts.others, qrs },
        history,
        harvestGrew,
      });

      history.push({
        step: step + 1,
        action: resolved.action?.label || resolved.operation,
        kind: resolved.action?.kind,
        operation: resolved.operation,
        target: resolved.target,
        node: resolved.action?.node,
        href: resolved.action?.href,
        url: snapshot.url,
        delta: resolved.action?.delta,
        reason: resolved.reason,
        noul_contacts: answers.page_has_contacts?.noul,
        noul_nav: answers.promising_nav?.noul,
        model,
        page_changed: null,
      });
      emit({ ...snapshotHarvest(), trace: history });

      if (resolved.operation === "DONE" || resolved.operation === "BLOCKED") {
        return finishFind(emit, {
          foundNow,
          contacts,
          qrs,
          pages,
          history,
          resolved,
          sourceUrl: askedUrl,
        });
      }

      emit({
        message: formatProgressStep(history[history.length - 1]),
      });
      const outcome = await executeResolved(driveTab, resolved, {
        scrollY: snapshot.scroll?.y || 0,
        keepTabId,
      });
      const nextTabId = outcome?.nextTabId;
      if (nextTabId && nextTabId !== driveTab) {
        sessionTabs.add(nextTabId);
        await hudTeardown(driveTab);
        await detach(driveTab);
        driveTab = nextTabId;
        await attach(driveTab);
        await hudInstall(driveTab);
      }
    }

    const budgetMemory = rememberedFlags(askedUrl, contacts, qrs);
    emit({
      ...snapshotHarvest(),
      status: budgetMemory.alreadyEmpty ? "done" : "done",
      message: budgetMemory.message || COPY.statusBudget,
      note: budgetMemory.note || "",
      alreadyEmpty: Boolean(budgetMemory.alreadyEmpty),
      alreadyChecked: Boolean(budgetMemory.alreadyChecked),
      sourceUrl: askedUrl,
    });
    return state;
  } catch (err) {
    const foundNow = tally();
    const timedOut = /timeout|abort/i.test(String(err?.message || err));
    if (timedOut || foundNow) {
      return finishFind(emit, {
        foundNow,
        contacts,
        qrs,
        pages,
        history,
        timedOut,
        sourceUrl: askedUrl,
      });
    }
    emit({
      status: "error",
      error: String(err?.message || err),
      message: formatError(err),
      phones: contacts.phones,
      emails: contacts.emails,
      others: contacts.others,
      qrs,
      pages,
      trace: history,
    });
    return state;
  } finally {
    const closing = tabsToClose(sessionTabs, [keepTabId]);
    for (const id of sessionTabs) {
      await hudTeardown(id);
      await detach(id);
    }
    for (const id of closing) {
      await chrome.tabs.remove(id).catch(() => {});
    }
  }
}

async function resolveTab(requestedId) {
  if (requestedId) {
    try {
      return await chrome.tabs.get(requestedId);
    } catch {
      /* fall through */
    }
  }
  const tabs = await chrome.tabs.query({ lastFocusedWindow: true });
  const httpTabs = tabs.filter((t) => /^https?:/.test(t.url || ""));
  const activeHttp = httpTabs.find((t) => t.active);
  return activeHttp || httpTabs[0] || tabs.find((t) => t.active) || null;
}

function beginBackgroundFind(url, openerTabId) {
  const seq = ++runSeq;
  publish({
    ...emptyState(),
    status: "running",
    phase: "observe",
    message: COPY.statusStarting,
    sourceUrl: url,
    startedAt: Date.now(),
  });
  openQuietTab(url, openerTabId)
    .then((tab) => {
      if (seq !== runSeq) {
        chrome.tabs.remove(tab.id).catch(() => {});
        return null;
      }
      return runFind(tab.id, { seq, sourceUrl: url, keepTabId: openerTabId });
    })
    .catch((err) => {
      if (seq !== runSeq) return;
      publish({
        status: "error",
        error: String(err?.message || err),
        message: formatError(err),
        sourceUrl: url,
      });
    });
}

async function startFindForLink(url, openerTabId) {
  if (!isWebpageUrl(url)) {
    publish({
      ...emptyState(),
      status: "error",
      error: COPY.errorNoTab,
      message: COPY.errorNoTab,
    });
    return;
  }
  if (!(await ensureApiKey())) return;
  const saved = recallSite(checkedSites, url);
  if (saved) {
    publish(memoryState(saved, { id: openerTabId, url }));
    return;
  }
  beginBackgroundFind(url, openerTabId);
}

async function startFindForTab(tab, { force = false } = {}) {
  const blocked = startErrorForTab(tab);
  if (blocked) {
    publish({
      ...emptyState(),
      status: "error",
      error: blocked,
      message: blocked,
      tabId: tab?.id ?? null,
    });
    return state;
  }
  if (!(await ensureApiKey())) return state;
  const saved = recallSite(checkedSites, tab.url);
  if (saved && (saved.empty || !force)) {
    publish(memoryState(saved, tab));
    return state;
  }
  beginBackgroundFind(tab.url, tab.id);
  return state;
}

async function startBatch(text) {
  const parsed = parseUrlList(text);
  if (!parsed.items.length) {
    publish({
      ...emptyState(),
      mode: "batch",
      status: "error",
      message: COPY.batchEmpty,
      error: COPY.batchEmpty,
    });
    return state;
  }
  if (!(await ensureApiKey())) return state;
  const seq = ++runSeq;
  const jobs = parsed.items.map((item) => {
    if (item.kind === "skip") {
      return {
        kind: "skip",
        url: item.line || "（空行）",
        status: "skipped",
        note: item.note,
        phones: [],
        emails: [],
        others: [],
        qrs: [],
      };
    }
    return {
      kind: "url",
      url: item.url,
      status: "pending",
      phones: [],
      emails: [],
      others: [],
      qrs: [],
    };
  });
  const plan = planBackgroundTabs(parsed.accepted);
  const urlCount = plan.length;
  publish({
    ...emptyState(),
    mode: "batch",
    status: urlCount ? "running" : "done",
    message: urlCount ? `正在查找第 1 个，共 ${urlCount} 个` : COPY.batchDone,
    jobs,
    batchIndex: urlCount ? 1 : 0,
    batchTotal: urlCount,
  });
  runBatchJobs(seq, jobs, plan).catch((err) => {
    publish({
      status: "error",
      mode: "batch",
      error: String(err?.message || err),
      message: formatError(err),
    });
  });
  return state;
}

async function runBatchJobs(seq, jobs, plan) {
  const urlCount = plan.length;
  let planIndex = 0;
  for (let i = 0; i < jobs.length; i++) {
    if (seq !== runSeq) return state;
    if (jobs[i].kind !== "url") continue;
    const spec = plan[planIndex++];
    const saved = recallSite(checkedSites, spec.url);
    if (saved) {
      emitFind(i, {
        status: "done",
        phones: saved.phones || [],
        emails: saved.emails || [],
        others: saved.others || [],
        qrs: saved.qrs || [],
        message: saved.empty ? COPY.statusAlreadyEmpty : COPY.statusDone,
        note: saved.empty ? COPY.statusAlreadyEmpty : "",
      });
      continue;
    }
    publish({
      batchIndex: planIndex,
      batchTotal: urlCount,
      mode: "batch",
      status: "running",
      message: `正在查找第 ${planIndex} 个，共 ${urlCount} 个`,
    });
    try {
      const tab = await chrome.tabs.create({ url: spec.url, active: spec.active });
      await waitTabComplete(tab.id);
      await runFind(tab.id, { jobIndex: i, seq, sourceUrl: spec.url });
    } catch (err) {
      emitFind(i, { status: "error", message: formatError(err) });
    }
  }
  if (seq !== runSeq) return state;
  publish({
    status: "done",
    mode: "batch",
    message: COPY.batchDone,
    jobs: state.jobs,
  });
  return state;
}

let menuQueue = Promise.resolve();

function installLinkMenu() {
  menuQueue = menuQueue
    .then(async () => {
      await chrome.contextMenus.removeAll();
      await chrome.contextMenus.create(linkMenuSpec());
    })
    .catch(() => {});
}

chrome.runtime.onInstalled.addListener(() => installLinkMenu());
installLinkMenu();

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== LINK_MENU_ID) return;
  startFindForLink(info.linkUrl, tab?.id);
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "GET_STATE") {
    sendResponse(state);
    return;
  }
  if (message?.type === "START_BATCH") {
    startBatch(message.text).then((next) => sendResponse(next));
    return true;
  }
  if (message?.type === "START_FIND") {
    resolveTab(message.tabId)
      .then((tab) => startFindForTab(tab, { force: Boolean(message.force) }))
      .then((next) => sendResponse(next))
      .catch((err) => {
        publish({
          status: "error",
          error: String(err?.message || err),
          message: formatError(err),
        });
        sendResponse(state);
      });
    return true;
  }
  return undefined;
});

chrome.storage.session
  .get(["jevfinder", "checkedSites"])
  .then((got) => {
    if (got?.checkedSites && typeof got.checkedSites === "object") checkedSites = got.checkedSites;
    if (got?.jevfinder && typeof got.jevfinder === "object") {
      state = { ...emptyState(), ...reviveStoredState(got.jevfinder) };
      chrome.storage.session.set({ jevfinder: state }).catch(() => {});
    }
    syncActionIcon(state);
  })
  .catch(() => {
    syncActionIcon(state);
  });

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "session" && changes.checkedSites) {
    checkedSites = changes.checkedSites.newValue || {};
  }
  if (area === "sync" && changes.typesafeApiKey) {
    checkedSites = {};
    chrome.storage.session.set({ checkedSites: {} }).catch(() => {});
  }
});
