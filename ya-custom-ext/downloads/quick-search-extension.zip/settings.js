const DOMAIN_SETTINGS_KEY = "connectionSettingsV3";

const form = document.querySelector("#settings-form");
const pageDomainInput = document.querySelector("#page-domain");
const apiDomainInput = document.querySelector("#api-domain");
const saveButton = document.querySelector("#save-settings");
const clearButton = document.querySelector("#clear-settings");
const messageElement = document.querySelector("#settings-message");

loadSettings().catch((error) => showMessage(error.message || "无法读取设置", true));

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  setSaving(true);
  hideMessage();

  try {
    const settings = {
      pageDomain: normalizeDomain(pageDomainInput.value),
      apiDomain: normalizeDomain(apiDomainInput.value)
    };
    const origins = [
      `https://${settings.pageDomain}/*`,
      `https://${settings.apiDomain}/*`
    ];
    const missingOrigins = [];

    for (const origin of origins) {
      const granted = await chrome.permissions.contains({ origins: [origin] });
      if (!granted) missingOrigins.push(origin);
    }

    if (missingOrigins.length) {
      const granted = await chrome.permissions.request({ origins: missingOrigins });
      if (!granted) throw new Error("未授权访问填写的域名，设置未保存");
    }

    await chrome.storage.local.set({ [DOMAIN_SETTINGS_KEY]: settings });
    const response = await chrome.runtime.sendMessage({ type: "settingsUpdated" });
    if (!response?.ok) throw new Error(response?.message || "后台未能加载新设置");

    const saved = (await chrome.storage.local.get(DOMAIN_SETTINGS_KEY))[DOMAIN_SETTINGS_KEY];
    if (saved?.pageDomain !== settings.pageDomain || saved?.apiDomain !== settings.apiDomain) {
      throw new Error("设置写入校验失败");
    }

    showMessage("设置已保存并生效");
  } catch (error) {
    showMessage(error.message || "无法保存设置", true);
  } finally {
    setSaving(false);
  }
});

clearButton.addEventListener("click", async () => {
  setSaving(true);
  hideMessage();
  try {
    await chrome.storage.local.remove(DOMAIN_SETTINGS_KEY);
    const response = await chrome.runtime.sendMessage({ type: "settingsUpdated" });
    if (!response?.ok) throw new Error(response?.message || "后台未能清除设置");
    pageDomainInput.value = "";
    apiDomainInput.value = "";
    showMessage("配置已清除");
  } catch (error) {
    showMessage(error.message || "无法清除设置", true);
  } finally {
    setSaving(false);
  }
});

async function loadSettings() {
  const stored = (await chrome.storage.local.get(DOMAIN_SETTINGS_KEY))[DOMAIN_SETTINGS_KEY] || {};
  pageDomainInput.value = stored.pageDomain || "";
  apiDomainInput.value = stored.apiDomain || "";
}

function normalizeDomain(rawValue) {
  const value = String(rawValue || "").trim().toLowerCase().replace(/\.$/, "");
  const labels = value.split(".");
  const valid = value.length <= 253
    && labels.length >= 2
    && labels.every((label) => label.length <= 63
      && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(label));
  if (!valid) throw new Error("请输入有效域名，不要包含协议、端口或路径");
  return value;
}

function setSaving(saving) {
  saveButton.disabled = saving;
  clearButton.disabled = saving;
  pageDomainInput.disabled = saving;
  apiDomainInput.disabled = saving;
  saveButton.textContent = saving ? "正在处理…" : "保存并生效";
}

function showMessage(message, isError = false) {
  messageElement.textContent = message;
  messageElement.classList.toggle("error", isError);
  messageElement.hidden = false;
}

function hideMessage() {
  messageElement.hidden = true;
  messageElement.classList.remove("error");
}
