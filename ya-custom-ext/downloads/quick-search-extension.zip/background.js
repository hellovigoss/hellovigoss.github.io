const DOMAIN_SETTINGS_KEY = "connectionSettingsV3";
const LEGACY_DOMAIN_SETTINGS_KEYS = ["domainSettings", "connectionDomainsV2"];
const MIGRATION_KEY = "genericNamingMigrationV1";
const PAGE_PATH = "/customer/work-space/customer";
const API_PATH = "/api/account/GlobalQueryAccount";
const AUTH_STATE_KEY = "queryAuthStateV3";
const MAX_CONCURRENT_QUERIES = 5;

let activeQueryCount = 0;
const pendingQueries = [];
let domainSettings = { pageDomain: "", apiDomain: "" };
let settingsReady;
settingsReady = loadDomainSettings();

// 只在 Chrome 当前会话中保存必要请求头，关闭浏览器后自动清理。
async function captureAuthHeaders(details) {
  const headers = Object.fromEntries(
    (details.requestHeaders || []).map(({ name, value }) => [name.toLowerCase(), value || ""])
  );

  const authorization = headers.authorization;
  const csrfToken = headers["x-csrftoken"];
  if (!authorization && !csrfToken) return;

  const previous = (await chrome.storage.session.get(AUTH_STATE_KEY))[AUTH_STATE_KEY] || {};
  await chrome.storage.session.set({
    [AUTH_STATE_KEY]: {
      authorization: authorization || previous.authorization || "",
      csrfToken: csrfToken || previous.csrfToken || "",
      lastSeenAt: Date.now()
    }
  });
}

function isValidDomain(value) {
  if (typeof value !== "string" || value.length > 253) return false;
  const labels = value.split(".");
  return labels.length >= 2 && labels.every((label) => (
    label.length >= 1
    && label.length <= 63
    && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i.test(label)
  ));
}

function sanitizeDomainSettings(value) {
  const pageDomain = String(value?.pageDomain || "").trim().toLowerCase().replace(/\.$/, "");
  const apiDomain = String(value?.apiDomain || "").trim().toLowerCase().replace(/\.$/, "");
  return {
    pageDomain: isValidDomain(pageDomain) ? pageDomain : "",
    apiDomain: isValidDomain(apiDomain) ? apiDomain : ""
  };
}

function configureAuthListener() {
  if (chrome.webRequest.onBeforeSendHeaders.hasListener(captureAuthHeaders)) {
    chrome.webRequest.onBeforeSendHeaders.removeListener(captureAuthHeaders);
  }
  if (!domainSettings.apiDomain) return;
  chrome.webRequest.onBeforeSendHeaders.addListener(
    captureAuthHeaders,
    { urls: [`https://${domainSettings.apiDomain}/*`] },
    ["requestHeaders", "extraHeaders"]
  );
}

async function loadDomainSettings() {
  const migration = await chrome.storage.local.get(MIGRATION_KEY);
  if (!migration[MIGRATION_KEY]) {
    await chrome.storage.session.clear();
    await chrome.storage.local.remove(LEGACY_DOMAIN_SETTINGS_KEYS);
    await chrome.storage.local.set({ [MIGRATION_KEY]: true });
  }
  const stored = (await chrome.storage.local.get(DOMAIN_SETTINGS_KEY))[DOMAIN_SETTINGS_KEY];
  domainSettings = sanitizeDomainSettings(stored);
  configureAuthListener();
  return domainSettings;
}

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local" || !changes[DOMAIN_SETTINGS_KEY]) return;
  const previousSettings = domainSettings;
  domainSettings = sanitizeDomainSettings(changes[DOMAIN_SETTINGS_KEY].newValue);
  if (previousSettings.pageDomain !== domainSettings.pageDomain
    || previousSettings.apiDomain !== domainSettings.apiDomain) {
    chrome.storage.session.remove(AUTH_STATE_KEY);
  }
  configureAuthListener();
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message)
    .then(sendResponse)
    .catch((error) => sendResponse({ ok: false, code: "EXTENSION_ERROR", message: error.message }));
  return true;
});

async function handleMessage(message) {
  await settingsReady;
  if (message?.type === "status") return getStatus();
  if (message?.type === "openPage") return openPage();
  if (message?.type === "query") return scheduleQuery(message.keyword);
  if (message?.type === "settingsUpdated") {
    settingsReady = loadDomainSettings();
    await settingsReady;
    return { ok: true };
  }
  return { ok: false, code: "UNKNOWN_MESSAGE", message: "不支持的操作" };
}

function scheduleQuery(keyword) {
  return new Promise((resolve, reject) => {
    pendingQueries.push({ keyword, resolve, reject });
    drainQueryQueue();
  });
}

function drainQueryQueue() {
  while (activeQueryCount < MAX_CONCURRENT_QUERIES && pendingQueries.length) {
    const task = pendingQueries.shift();
    activeQueryCount += 1;

    queryAccount(task.keyword)
      .then(task.resolve, task.reject)
      .finally(() => {
        activeQueryCount -= 1;
        drainQueryQueue();
      });
  }
}

async function findPageTab() {
  if (!domainSettings.pageDomain) return null;
  const tabs = await chrome.tabs.query({ url: `https://${domainSettings.pageDomain}/*` });
  return tabs[0] || null;
}

async function openPage() {
  if (!domainSettings.pageDomain || !domainSettings.apiDomain) {
    return { ok: false, code: "NEED_SETTINGS", message: "请先打开设置并填写页面域名和接口域名" };
  }
  const pageUrl = `https://${domainSettings.pageDomain}${PAGE_PATH}`;
  const existing = await findPageTab();
  if (existing) {
    await chrome.tabs.update(existing.id, { active: true, url: pageUrl });
    if (existing.windowId) await chrome.windows.update(existing.windowId, { focused: true });
    return { ok: true };
  }

  await chrome.tabs.create({ url: pageUrl, active: true });
  return { ok: true };
}

async function getStatus() {
  const tab = await findPageTab();
  const authState = (await chrome.storage.session.get(AUTH_STATE_KEY))[AUTH_STATE_KEY];
  return {
    ok: true,
    hasPageTab: Boolean(tab),
    connected: Boolean(tab && authState?.lastSeenAt),
    configured: Boolean(domainSettings.pageDomain && domainSettings.apiDomain),
    lastSeenAt: authState?.lastSeenAt || null,
    domains: { ...domainSettings }
  };
}

async function queryAccount(rawKeyword) {
  const keyword = String(rawKeyword || "").trim();
  if (!keyword) {
    return { ok: false, code: "EMPTY_KEYWORD", message: "请输入客户名称" };
  }

  if (!domainSettings.pageDomain || !domainSettings.apiDomain) {
    return { ok: false, code: "NEED_SETTINGS", message: "请先打开设置并填写页面域名和接口域名" };
  }

  const tab = await findPageTab();
  if (!tab?.id) {
    return {
      ok: false,
      code: "NEED_LOGIN",
      message: "请先点击“打开页面”并完成登录，然后再查询"
    };
  }

  const authState = (await chrome.storage.session.get(AUTH_STATE_KEY))[AUTH_STATE_KEY] || {};
  const apiUrl = `https://${domainSettings.apiDomain}${API_PATH}`;

  let injection;
  try {
    [injection] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      args: [apiUrl, keyword, authState.authorization || "", authState.csrfToken || ""],
      func: async (apiUrl, searchKeyword, authorization, csrfToken) => {
        const headers = {
          accept: "application/json, text/plain, */*",
          "content-type": "application/json",
          "x-date": new Date().toISOString(),
          "x-expires": "300"
        };
        if (authorization) headers.authorization = authorization;
        if (csrfToken) headers["x-csrftoken"] = csrfToken;

        const response = await fetch(apiUrl, {
          method: "POST",
          credentials: "include",
          headers,
          body: JSON.stringify({ PageNo: 1, PageSize: 10, Keyword: searchKeyword })
        });

        const text = await response.text();
        let data;
        try {
          data = text ? JSON.parse(text) : null;
        } catch {
          data = text;
        }

        return { ok: response.ok, status: response.status, data };
      }
    });
  } catch (error) {
    return {
      ok: false,
      code: "PAGE_NOT_READY",
      message: "目标页面还没有准备好，请完成登录并等待页面加载后重试",
      detail: error.message
    };
  }

  const result = injection?.result;
  if (!result?.ok) {
    if (result?.status === 401 || result?.status === 403) {
      return {
        ok: false,
        code: "NEED_LOGIN",
        message: "登录态已失效，请刷新目标页面并重新登录",
        detail: result?.data
      };
    }
    return {
      ok: false,
      code: "API_ERROR",
      message: `接口返回错误（${result?.status || "未知"}）`,
      status: result?.status || null,
      detail: result?.data
    };
  }

  const baseResp = result.data?.BaseResp || result.data?.baseResp;
  if (isBaseResponseFailure(baseResp)) {
    return {
      ok: false,
      code: "API_ERROR",
      message: baseResp.StatusMessage || baseResp.ErrorCode || "业务查询失败",
      status: Number(baseResp.HttpCode) || result.status || null,
      detail: result.data
    };
  }

  return { ok: true, data: result.data };
}

function isBaseResponseFailure(baseResp) {
  if (!baseResp || typeof baseResp !== "object") return false;

  const httpCode = Number(baseResp.HttpCode);
  const statusCode = String(baseResp.StatusCode ?? "0").toLowerCase();
  const errorCode = String(baseResp.ErrorCode ?? "ok").toLowerCase();
  const successfulErrorCodes = new Set(["", "0", "ok", "success"]);

  return (Number.isFinite(httpCode) && httpCode >= 400)
    || statusCode !== "0"
    || !successfulErrorCodes.has(errorCode);
}
