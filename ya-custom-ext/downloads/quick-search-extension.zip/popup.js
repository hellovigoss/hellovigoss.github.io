const statusElement = document.querySelector("#status");
const form = document.querySelector("#query-form");
const keywordInput = document.querySelector("#keyword");
const queryButton = document.querySelector("#query-button");
const openButton = document.querySelector("#open-page");
const messageElement = document.querySelector("#message");
const resultSection = document.querySelector("#result-section");
const resultElement = document.querySelector("#result");
const resultSummaryElement = document.querySelector("#result-summary");
const copyButton = document.querySelector("#copy-result");
const excelFileInput = document.querySelector("#excel-file");
const fileInfoElement = document.querySelector("#file-info");
const batchButton = document.querySelector("#batch-query");
const batchProgress = document.querySelector("#batch-progress");
const openSettingsButton = document.querySelector("#open-settings");
const domainSummary = document.querySelector("#domain-summary");

const MAX_BATCH_ROWS = 10000;
const MAX_EXCEL_FILE_SIZE = 20 * 1024 * 1024;
const MAX_CONCURRENT_QUERIES = 5;
const MAX_QUERY_RETRIES = 2;
const RESULT_COLUMNS = ["客户名", "客户编号", "客户简称", "负责销售（所有人）"];

let batchKeywords = [];
let xlsxLoadPromise = null;
let quickResultRows = [];
let quickResultHeaders = [];

refreshStatus().catch(() => {
  statusElement.textContent = "连接状态暂不可用，请重新打开扩展";
  setStatusMode("offline");
});

openButton.addEventListener("click", async () => {
  const response = await chrome.runtime.sendMessage({ type: "openPage" });
  if (response?.ok) {
    window.close();
    return;
  }
  showMessage(response?.message || "无法打开页面", true);
});

openSettingsButton.addEventListener("click", async () => {
  const width = 560;
  const height = 560;
  const currentWindow = await chrome.windows.getCurrent();
  const createOptions = {
    url: chrome.runtime.getURL("settings.html"),
    type: "popup",
    width,
    height,
    focused: true
  };

  if (Number.isFinite(currentWindow.left)
    && Number.isFinite(currentWindow.top)
    && Number.isFinite(currentWindow.width)
    && Number.isFinite(currentWindow.height)) {
    createOptions.left = Math.round(currentWindow.left + (currentWindow.width - width) / 2);
    createOptions.top = Math.round(currentWindow.top + (currentWindow.height - height) / 2);
  }

  await chrome.windows.create(createOptions);
  window.close();
});

function renderDomains(settings) {
  const domains = [settings?.pageDomain, settings?.apiDomain].filter(Boolean);
  domainSummary.textContent = domains.join(" · ");
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const keyword = keywordInput.value.trim();
  if (!keyword) {
    showMessage("请先输入客户名称", true);
    keywordInput.focus();
    return;
  }

  setLoading(true);
  hideMessage();
  resultSection.hidden = true;

  try {
    const response = await chrome.runtime.sendMessage({ type: "query", keyword });
    const outcome = classifyQueryResponse(response);
    renderQuickQueryResult(keyword, response);

    if (outcome.kind === "failure") {
      showMessage(outcome.errorMessage, response?.code !== "NEED_LOGIN");
    }

    await refreshStatus();
  } catch (error) {
    const response = { ok: false, code: "EXTENSION_ERROR", message: error.message };
    renderQuickQueryResult(keyword, response);
    showMessage(error.message || "查询失败，请稍后重试", true);
  } finally {
    setLoading(false);
  }
});

copyButton.addEventListener("click", async () => {
  if (!quickResultRows.length) return;
  await navigator.clipboard.writeText(rowsToTsv(quickResultRows, quickResultHeaders));
  copyButton.textContent = "已复制";
  setTimeout(() => { copyButton.textContent = "复制表格"; }, 1200);
});

excelFileInput.addEventListener("change", async () => {
  batchKeywords = [];
  batchButton.disabled = true;
  batchProgress.hidden = true;

  const file = excelFileInput.files?.[0];
  if (!file) {
    fileInfoElement.textContent = "首列为客户名！不需要表头！一个客户一行！";
    return;
  }

  try {
    await loadXlsx();

    if (file.size > MAX_EXCEL_FILE_SIZE) {
      throw new Error("文件不能超过 20 MB");
    }

    const workbook = XLSX.read(await file.arrayBuffer(), {
      type: "array",
      sheets: 0,
      sheetRows: MAX_BATCH_ROWS + 2
    });
    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    const firstColumnRange = XLSX.utils.decode_range(firstSheet?.["!ref"] || "A1:A1");
    firstColumnRange.s.c = 0;
    firstColumnRange.e.c = 0;
    const rows = XLSX.utils.sheet_to_json(firstSheet, {
      header: 1,
      raw: false,
      defval: "",
      range: firstColumnRange
    });

    batchKeywords = rows
      .map((row) => String(row?.[0] ?? "").trim())
      .filter(Boolean);

    if (batchKeywords.length > MAX_BATCH_ROWS) {
      throw new Error(`客户数量超过 ${MAX_BATCH_ROWS} 行，请拆分文件后重试`);
    }

    if (!batchKeywords.length) throw new Error("第一列没有可查询的客户名称");

    fileInfoElement.textContent = `已读取 ${batchKeywords.length} 个客户；最多并发 ${MAX_CONCURRENT_QUERIES} 个请求。`;
    batchButton.disabled = false;
    hideMessage();
  } catch (error) {
    fileInfoElement.textContent = `文件读取失败：${error.message}`;
    showMessage(error.message || "请选择有效的 Excel 或 CSV 文件", true);
  }
});

batchButton.addEventListener("click", async () => {
  if (!batchKeywords.length) return;

  const queryResults = [];
  batchButton.disabled = true;
  excelFileInput.disabled = true;
  batchProgress.hidden = false;
  batchProgress.value = 0;
  hideMessage();

  try {
    const { results, stoppedResponse } = await runBatchQueries(batchKeywords, (completed) => {
      batchButton.textContent = "正在查询…";
      batchProgress.value = (completed / batchKeywords.length) * 100;
    });
    queryResults.push(...results);

    if (stoppedResponse) showMessage(stoppedResponse.message, false);

    const completed = queryResults.length;
    const outcomes = queryResults.map(({ response }) => classifyQueryResponse(response));
    const successful = outcomes.filter(({ kind }) => kind === "success").length;
    const empty = outcomes.filter(({ kind }) => kind === "empty").length;
    const failed = outcomes.filter(({ kind }) => kind === "failure").length;
    if (completed) exportQueryResults(queryResults);

    const resultNotice = completed ? "，结果已下载" : "";
    fileInfoElement.textContent = `已处理 ${completed} 个客户：有结果 ${successful} 个，无内容 ${empty} 个，失败 ${failed} 个${resultNotice}。`;
  } catch (error) {
    fileInfoElement.textContent = `批量处理失败：${error.message}`;
    showMessage(error.message || "批量处理失败，请稍后重试", true);
  } finally {
    batchButton.textContent = "批量查询并下载结果";
    batchButton.disabled = false;
    excelFileInput.disabled = false;
  }
});

async function refreshStatus() {
  const response = await chrome.runtime.sendMessage({ type: "status" });
  renderDomains(response?.domains);
  if (!response?.configured) {
    statusElement.textContent = "请先打开设置并填写页面域名和接口域名";
    setStatusMode("offline");
  } else if (response?.connected) {
    statusElement.textContent = "已连接，可直接查询";
    setStatusMode("ready");
  } else if (response?.hasPageTab) {
    statusElement.textContent = "未就绪，请保持目标页面打开并完成登录";
    setStatusMode("offline");
  } else {
    statusElement.textContent = "请打开目标页面，并保持标签页打开";
    setStatusMode("offline");
  }
}

function setStatusMode(mode) {
  statusElement.classList.remove("ready", "offline");
  statusElement.classList.add(mode);
}

function setLoading(loading) {
  queryButton.disabled = loading;
  keywordInput.disabled = loading;
  queryButton.textContent = loading ? "查询中…" : "立即查询";
}

function showMessage(message, isError = false) {
  messageElement.textContent = message;
  messageElement.classList.toggle("error", isError);
  messageElement.hidden = false;
}

function hideMessage() {
  messageElement.hidden = true;
  messageElement.classList.remove("error");
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function loadXlsx() {
  if (globalThis.XLSX) return Promise.resolve();
  if (xlsxLoadPromise) return xlsxLoadPromise;

  xlsxLoadPromise = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("xlsx.full.min.js");
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Excel 组件加载失败，请重新打开扩展后重试"));
    document.head.appendChild(script);
  });

  return xlsxLoadPromise;
}

function renderQuickQueryResult(keyword, response) {
  const outcome = classifyQueryResponse(response);
  quickResultRows = buildQuickQueryRows(keyword, response);
  quickResultHeaders = RESULT_COLUMNS;
  copyButton.disabled = !quickResultRows.length;

  if (outcome.kind === "success") {
    resultSummaryElement.textContent = `共 ${outcome.records.length} 条匹配记录，每条记录单独展示`;
  } else if (outcome.kind === "empty") {
    resultSummaryElement.textContent = "未查询到匹配记录";
  } else {
    resultSummaryElement.textContent = "查询失败，请根据错误信息处理";
  }

  const table = document.createElement("table");
  table.className = "result-table";

  const headRow = document.createElement("tr");
  for (const header of quickResultHeaders) {
    const cell = document.createElement("th");
    cell.scope = "col";
    cell.textContent = header;
    headRow.appendChild(cell);
  }
  const tableHead = document.createElement("thead");
  tableHead.appendChild(headRow);
  table.appendChild(tableHead);

  const tableBody = document.createElement("tbody");
  for (const row of quickResultRows) {
    const bodyRow = document.createElement("tr");
    for (const header of quickResultHeaders) {
      const cell = document.createElement("td");
      const value = formatTableValue(row[header]);
      cell.textContent = value;
      cell.title = value;
      if (header === "客户名") cell.classList.add("cell-wrap");
      bodyRow.appendChild(cell);
    }
    tableBody.appendChild(bodyRow);
  }
  table.appendChild(tableBody);

  resultElement.replaceChildren(table);
  resultSection.hidden = false;
}

function buildQuickQueryRows(keyword, response) {
  const outcome = classifyQueryResponse(response);
  if (outcome.kind !== "success") return [];
  return outcome.records.map(projectCustomerRecord);
}

function projectCustomerRecord(record) {
  return {
    "客户名": record?.Name ?? "",
    "客户编号": record?.AccountNumberC ?? "",
    "客户简称": record?.ShortNameC ?? "",
    "负责销售（所有人）": record?.Owner?.Name ?? ""
  };
}

function formatTableValue(value) {
  if (value === true) return "是";
  if (value === false) return "否";
  return stringifyCell(value);
}

function rowsToTsv(rows, headers) {
  const escapeCell = (value) => formatTableValue(value).replace(/[\t\r\n]+/g, " ");
  return [
    headers.join("\t"),
    ...rows.map((row) => headers.map((header) => escapeCell(row[header])).join("\t"))
  ].join("\n");
}

async function runBatchQueries(keywords, onProgress) {
  const results = new Array(keywords.length);
  let nextIndex = 0;
  let completed = 0;
  let stoppedResponse = null;

  async function worker() {
    while (!stoppedResponse) {
      const index = nextIndex;
      if (index >= keywords.length) return;
      nextIndex += 1;

      const keyword = keywords[index];
      const response = await queryWithRetry(keyword);
      results[index] = { keyword, response };
      completed += 1;
      onProgress(completed);

      if (response?.code === "NEED_LOGIN" || response?.code === "PAGE_NOT_READY") {
        stoppedResponse = response;
      }
    }
  }

  const workerCount = Math.min(MAX_CONCURRENT_QUERIES, keywords.length);
  await Promise.all(Array.from({ length: workerCount }, () => worker()));
  return { results: results.filter(Boolean), stoppedResponse };
}

async function queryWithRetry(keyword) {
  let response;

  for (let attempt = 0; attempt <= MAX_QUERY_RETRIES; attempt += 1) {
    try {
      response = await chrome.runtime.sendMessage({ type: "query", keyword });
    } catch (error) {
      response = { ok: false, code: "EXTENSION_ERROR", message: error.message };
    }

    const retryable = response?.status === 429 || response?.status >= 500 || response?.code === "EXTENSION_ERROR";
    if (!retryable || attempt === MAX_QUERY_RETRIES) return response;

    const backoff = 800 * (2 ** attempt) + Math.floor(Math.random() * 300);
    await delay(backoff);
  }

  return response;
}

function exportQueryResults(queryResults) {
  const resultRows = [];

  for (const { response } of queryResults) {
    const outcome = classifyQueryResponse(response);
    if (outcome.kind === "success") {
      resultRows.push(...outcome.records.map(projectCustomerRecord));
    }
  }

  const workbook = XLSX.utils.book_new();
  const resultSheet = XLSX.utils.aoa_to_sheet([RESULT_COLUMNS]);
  if (resultRows.length) {
    XLSX.utils.sheet_add_json(resultSheet, resultRows, {
      header: RESULT_COLUMNS,
      skipHeader: true,
      origin: "A2"
    });
  }
  formatSheet(resultSheet, resultRows, RESULT_COLUMNS);
  XLSX.utils.book_append_sheet(workbook, resultSheet, "查询结果");

  const now = new Date();
  const stamp = [
    now.getFullYear(),
    String(now.getMonth() + 1).padStart(2, "0"),
    String(now.getDate()).padStart(2, "0"),
    "_",
    String(now.getHours()).padStart(2, "0"),
    String(now.getMinutes()).padStart(2, "0")
  ].join("");
  XLSX.writeFile(workbook, `客户查询结果_${stamp}.xlsx`, { compression: true });
}

function classifyQueryResponse(response) {
  if (!response?.ok) {
    return {
      kind: "failure",
      label: "失败",
      records: [],
      errorMessage: response?.message || "未知错误"
    };
  }

  const payload = response.data;
  const baseResp = payload?.BaseResp || payload?.baseResp;
  if (isBaseResponseFailure(baseResp)) {
    return {
      kind: "failure",
      label: "失败",
      records: [],
      errorMessage: baseResp.StatusMessage || baseResp.ErrorCode || "业务查询失败"
    };
  }

  const directData = payload?.Data ?? payload?.data;
  const records = Array.isArray(directData)
    ? directData.filter((item) => item && typeof item === "object" && !Array.isArray(item))
    : findRecordArray(payload);

  return records.length
    ? { kind: "success", label: "有结果", records, errorMessage: "" }
    : { kind: "empty", label: "无内容", records: [], errorMessage: "" };
}

function isBaseResponseFailure(baseResp) {
  if (!baseResp || typeof baseResp !== "object") return false;

  const httpCode = Number(baseResp.HttpCode);
  const statusCode = String(baseResp.StatusCode ?? "0").toLowerCase();
  const errorCode = String(baseResp.ErrorCode ?? "ok").toLowerCase();
  const successfulErrorCodes = new Set(["", "0", "ok", "success"]);

  return (Number.isFinite(httpCode) && httpCode >= 400)
    || statusCode !== "0"
    || !successfulErrorCodes.has(errorCode);
}

function findRecordArray(value, depth = 0) {
  if (depth > 6 || value == null) return [];
  if (Array.isArray(value)) {
    return value.filter((item) => item && typeof item === "object" && !Array.isArray(item));
  }
  if (typeof value !== "object") return [];

  const preferredKeys = [
    "List", "list", "Records", "records", "Items", "items",
    "Accounts", "accounts", "Data", "data", "Result", "result"
  ];
  const entries = Object.entries(value).sort(([left], [right]) => {
    const leftIndex = preferredKeys.indexOf(left);
    const rightIndex = preferredKeys.indexOf(right);
    return (leftIndex < 0 ? 999 : leftIndex) - (rightIndex < 0 ? 999 : rightIndex);
  });

  for (const [, child] of entries) {
    const found = findRecordArray(child, depth + 1);
    if (found.length) return found;
  }
  return [];
}

function flattenRecord(record, prefix = "", depth = 0, output = {}) {
  if (!record || typeof record !== "object") return output;

  for (const [key, value] of Object.entries(record)) {
    const column = prefix ? `${prefix}.${key}` : key;
    if (value == null || typeof value !== "object") {
      output[column] = value ?? "";
    } else if (!Array.isArray(value) && depth < 1) {
      flattenRecord(value, column, depth + 1, output);
    } else {
      output[column] = stringifyCell(value);
    }
  }
  return output;
}

function stringifyCell(value) {
  if (value == null) return "";
  if (typeof value === "string") return value;
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

function formatSheet(sheet, rows, fixedHeaders = []) {
  if (!sheet["!ref"]) return;
  sheet["!autofilter"] = { ref: sheet["!ref"] };
  const headers = fixedHeaders.length
    ? fixedHeaders
    : [...new Set(rows.flatMap((row) => Object.keys(row)))];
  const widths = Object.fromEntries(headers.map((header) => [header, header.length]));

  for (const row of rows) {
    for (const [header, value] of Object.entries(row)) {
      widths[header] = Math.max(widths[header] || 0, String(value ?? "").length);
    }
  }

  sheet["!cols"] = headers.map((header) => ({
    wch: Math.min(Math.max(widths[header] + 2, 12), 42)
  }));
}
